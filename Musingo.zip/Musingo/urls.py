from django.urls import path
from .views import dashboard,release_document,register_document,admin_document_list,request_document,reverse_action,approve_document,document_detail,document_list, active_list,muno,user_document_list


urlpatterns = [
    path('admin_documents/', admin_document_list, name='admin_document_list'),
    path('documents/', admin_document_list, name='user_document_list'),
    path('documents/<int:pk>/request/', request_document, name='request_document'),
    path('documents/<int:pk>/approve/', approve_document, name='approve_document'),
    path('documents/<int:pk>/release/', release_document, name='release_document'),
    path('documents/<int:pk>/reverse/', reverse_action, name='reverse_action'),
    path('documents/', admin_document_list, name='document_list'),
    path('documents/<int:pk>/', document_detail, name='document_detail'),
    path('documents/<int:pk>/approve/', approve_document, name='approve_document'),
    path('documents/<int:pk>/request/', request_document, name='request_document'),
    path('documents/<int:pk>/release/', release_document, name='release_document'),
    path('active/', active_list, name='active_list'),
    path('active/<int:pk>/', document_detail, name='document_detail'),
    path('active/<int:pk>/approve/', approve_document, name='approve_document'),
    path('active/<int:pk>/request/', request_document, name='request_document'),
    path('active/<int:pk>/release/', release_document, name='release_document'),
    path('register_musingo/', muno, name='regMuno'),
    path('user-documents/', user_document_list, name='user_document_list'),
    path('document/register/<str:cus_id>/',register_document, name='register_document'),

    
    path('dashboard/', dashboard, name='dashboard'),
]