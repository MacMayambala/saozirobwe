from django.apps import AppConfig


class MusingoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Musingo'
