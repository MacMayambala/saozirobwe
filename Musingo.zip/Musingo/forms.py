from django import forms
from .models import DocumentCustody

class DocumentCustodyForm(forms.ModelForm):
    class Meta:
        model = DocumentCustody
        fields = [
            'document_type',
            'document_description',
            'received_by',
            'date_received',
            'next_of_kin_name',
            'next_of_kin_phone',
            'next_of_kin_relationship',
        ]
        widgets = {
            'date_received': forms.DateInput(attrs={'type': 'date'}),
            'document_description': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
            'document_type': forms.TextInput(attrs={'class': 'form-control'}),
            'received_by': forms.TextInput(attrs={'class': 'form-control'}),
            'next_of_kin_name': forms.TextInput(attrs={'class': 'form-control'}),
            'next_of_kin_phone': forms.TextInput(attrs={'class': 'form-control'}),
            'next_of_kin_relationship': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add Bootstrap 'form-control' class to all fields for consistent styling
        for field in self.fields.values():
            if 'class' not in field.widget.attrs:
                field.widget.attrs['class'] = 'form-control'