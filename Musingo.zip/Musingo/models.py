
# models.py

from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _

# Assuming Customer model is in the same app; otherwise, adjust the import
from Customer.models import Customer  # Adjust this import based on your app structure

class DocumentCustody(models.Model):
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('requested', 'Requested'),
        ('Pending', 'Pending'),
        ('released', 'Released'),
    ]
    
    # Link to the Customer model
    customer = models.ForeignKey(
        Customer,
        on_delete=models.CASCADE,  # Deletes document if customer is deleted; use SET_NULL if preferred
        related_name='documents'
    )
    
    document_type = models.CharField(max_length=255)
    document_description = models.TextField()
    received_by = models.CharField(max_length=255)
    date_received = models.DateField()
    
    # Optional: Next of kin specific to this document (if different from Customer's next of kin)
    next_of_kin_name = models.CharField(max_length=255, blank=True, null=True)
    next_of_kin_phone = models.CharField(max_length=15, blank=True, null=True)
    next_of_kin_relationship = models.CharField(max_length=255, blank=True, null=True)
    
    approved_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='approvals'
    )
    date_approved = models.DateTimeField(null=True, blank=True)
    
    requested_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='requests'
    )
    date_requested = models.DateTimeField(null=True, blank=True)
    
    released_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='releases'
    )
    date_released = models.DateTimeField(null=True, blank=True)
    collected_by = models.CharField(max_length=255, null=True, blank=True)
    
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='Pending'
    )

    def __str__(self):
        return f"{self.document_type} - {self.customer.first_name} {self.customer.surname}"


