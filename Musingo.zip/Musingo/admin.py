from django.contrib import admin



# Register your models here.

from django.contrib import admin
from .models import DocumentCustody

@admin.register(DocumentCustody)
class DocumentCustodyAdmin(admin.ModelAdmin):
    list_display = ('document_type',  'status', 'approved_by', 'date_approved', 'released_by', 'date_released')
    list_filter = ('status', 'date_received', 'date_approved', 'date_released')
    search_fields = ('member_name', 'document_type', 'account_number')
