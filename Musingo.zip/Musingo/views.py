from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponseBadRequest
from django.contrib.auth.hashers import check_password
from django.utils import timezone
from django.core.paginator import Paginator
from .models import DocumentCustody

@login_required
def request_document(request, pk):
    """Allows any logged-in user to request an available document"""
    if request.method != "POST":
        return HttpResponseBadRequest("Invalid request method.")

    try:
        document = get_object_or_404(DocumentCustody, pk=pk)
        password = request.POST.get("password")
        
        if not password or not check_password(password, request.user.password):
            messages.error(request, "Invalid password. Request failed.")
            return redirect("user_document_list")

        if document.status != "available":
            messages.error(request, "This document cannot be requested because it is not available.")
        else:
            document.status = "requested"
            document.requested_by = request.user
            document.date_requested = timezone.now()
            document.save()
            messages.success(request, "Document request sent successfully.")
    except Exception as e:
        messages.error(request, f"Error requesting document: {str(e)}")

    return redirect("user_document_list")

@login_required
def approve_document(request, pk):
    """Allows admins (staff) or superusers to approve a pending document"""
    if request.method != "POST":
        return HttpResponseBadRequest("Invalid request method.")

    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, "You do not have permission to approve documents.")
        return redirect("user_document_list")

    try:
        document = get_object_or_404(DocumentCustody, pk=pk)
        password = request.POST.get("password")
        
        if not password or not check_password(password, request.user.password):
            messages.error(request, "Invalid password. Approval failed.")
            return redirect("admin_document_list")

        if document.status != "Pending":
            messages.error(request, "Only pending documents can be approved.")
        else:
            document.status = "available"
            document.approved_by = request.user
            document.date_approved = timezone.now()
            document.save()
            messages.success(request, "Document approved successfully.")
    except Exception as e:
        messages.error(request, f"Error approving document: {str(e)}")

    return redirect("admin_document_list")

@login_required
def release_document(request, pk):
    """Allows admins (staff) or superusers to release a requested document"""
    if request.method != "POST":
        return HttpResponseBadRequest("Invalid request method.")

    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, "You do not have permission to release documents.")
        return redirect("user_document_list")

    try:
        document = get_object_or_404(DocumentCustody, pk=pk)
        password = request.POST.get("password")
        
        if not password or not check_password(password, request.user.password):
            messages.error(request, "Invalid password. Release failed.")
            return redirect("admin_document_list")

        if document.status != "requested":
            messages.error(request, "Only requested documents can be released.")
        else:
            document.status = "released"
            document.released_by = request.user
            document.date_released = timezone.now()
            document.collected_by = request.POST.get("collected_by", "Unknown")
            document.save()
            messages.success(request, "Document released successfully.")
    except Exception as e:
        messages.error(request, f"Error releasing document: {str(e)}")

    return redirect("admin_document_list")

@login_required
def reverse_action(request, pk):
    """Allows superusers to reverse any document status"""
    if request.method != "POST":
        return HttpResponseBadRequest("Invalid request method.")

    if not request.user.is_superuser:
        messages.error(request, "Only superusers can reverse actions.")
        return redirect("admin_document_list" if request.user.is_staff else "user_document_list")

    try:
        document = get_object_or_404(DocumentCustody, pk=pk)
        password = request.POST.get("password")
        
        if not password or not check_password(password, request.user.password):
            messages.error(request, "Invalid password. Reverse failed.")
            return redirect("admin_document_list")

        current_status = document.status
        if current_status == "available":
            document.status = "Pending"
            document.approved_by = None
            document.date_approved = None
            messages.success(request, "Document reverted to Pending.")
        elif current_status == "requested":
            document.status = "available"
            document.requested_by = None
            document.date_requested = None
            messages.success(request, "Document reverted to Available.")
        elif current_status == "released":
            document.status = "requested"
            document.released_by = None
            document.date_released = None
            document.collected_by = None
            messages.success(request, "Document reverted to Requested.")
        else:  # pending
            messages.error(request, "No previous state to revert to from Pending.")
            return redirect("admin_document_list")

        document.save()
    except Exception as e:
        messages.error(request, f"Error reversing action: {str(e)}")

    return redirect("admin_document_list")


from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.paginator import Paginator
from .models import DocumentCustody
@login_required
def admin_document_list(request):
    """Displays all documents for admins (staff) and superusers"""
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, "Only admins can access this page.")
        return redirect("user_document_list")

    query = request.GET.get('q', '')
    documents = DocumentCustody.objects.all()
    if query:
        # Filter by customer member_number or other relevant field instead of account_number
        documents = documents.filter(customer__member_number__icontains=query)
    
    # Order by most recent date_received (descending order)
    documents = documents.order_by('-date_received')
    
    paginator = Paginator(documents, 10)  # 10 documents per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'document_list.html', {
        'page_obj': page_obj,
        'query': query,
    })
@login_required
def user_document_list(request):
    """Displays documents for all logged-in users"""
    query = request.GET.get('q', '')
    documents = DocumentCustody.objects.all()
    if query:
        documents = documents.filter(account_number__icontains=query)
    documents = documents.order_by('-date_received')
    
    paginator = Paginator(documents, 10)  # 10 documents per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'user_document_list.html', {
        'page_obj': page_obj,
        'query': query,
    })
@login_required
def document_list(request):
    """ Displays a paginated list of documents """
    query = request.GET.get("q", "")
    documents = DocumentCustody.objects.all()

    if query:
        documents = documents.filter(member_name__icontains=query)

    paginator = Paginator(documents, 5)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    return render(request, "document_list.html", {"page_obj": page_obj, "query": query})


@login_required
def document_detail(request, pk):
    """ Shows details of a specific document """
    document = get_object_or_404(DocumentCustody, pk=pk)
    return render(request, 'document_detail.html', {'document': document})


from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import DocumentCustody
from staff_management.models import Staff  # Adjust import path for Staff
from django.db.models import Avg, Sum, Count
from django.utils import timezone
from datetime import timedelta

@login_required
def dashboard(request):
    # Get today's date
    today = timezone.now().date()
    start_of_month = today.replace(day=1)
    start_of_year = today.replace(month=1, day=1)
    
    # Fetch data for summary cards
    total_misingo_today = DocumentCustody.objects.filter(date_registered=today).count()
    # Calculate growth percentage compared to previous day
    yesterday = today - timedelta(days=1)
    total_misingo_yesterday = DocumentCustody.objects.filter(date_registered=yesterday).count()
    
    if total_misingo_yesterday > 0:
        misingo_growth = ((total_misingo_today - total_misingo_yesterday) / total_misingo_yesterday) * 100
    else:
        misingo_growth = 0
    
    # Active Misingo (this month)
    active_misingo_month = DocumentCustody.objects.filter(
        date_registered__gte=start_of_month,
        status='Approved'
    ).aggregate(Sum('current_value'))['current_value__sum'] or 0
    
    # Taken Misingo (this year) - assuming 'date_taken' is not None means it's been taken
    taken_misingo_year = DocumentCustody.objects.filter(
        date_registered__gte=start_of_year,
        date_taken__isnull=False
    ).count()
    
    # Calculate year-over-year change for taken misingo
    last_year_start = start_of_year.replace(year=start_of_year.year-1)
    last_year_end = today.replace(year=today.year-1)
    taken_misingo_last_year = DocumentCustody.objects.filter(
        date_registered__gte=last_year_start,
        date_registered__lte=last_year_end,
        date_taken__isnull=False
    ).count()
    
    if taken_misingo_last_year > 0:
        taken_misingo_change = ((taken_misingo_year - taken_misingo_last_year) / taken_misingo_last_year) * 100
    else:
        taken_misingo_change = 0
    
    # Fetch applications for Recent Misingo table (limit to most recent)
    applications = DocumentCustody.objects.all().order_by('-date_registered')[:10]
    
    # Fetch staff data for performance graphs
    staff_list = Staff.objects.all()
    for staff in staff_list:
        # Calculate average completion percentage
        avg_completion = staff.targets.aggregate(Avg('completion_percentage'))['completion_percentage__avg']
        staff.avg_completion = round(avg_completion, 1) if avg_completion is not None else 0
        
        # Calculate total shares brought (sum of current_value)
        total_shares = staff.targets.aggregate(Sum('current_value'))['current_value__sum']
        staff.total_shares = total_shares if total_shares is not None else 0
    
    # Prepare context for template
    context = {
        'applications': applications,
        'staff_list': staff_list,
        'total_misingo': total_misingo_today,
        'misingo_growth': misingo_growth,
        'active_misingo': active_misingo_month,
        'taken_misingo': taken_misingo_year,
        'taken_misingo_change': taken_misingo_change
    }
    
    # Render dashboard with context data
    return render(request, 'dashboard.html', context)
@login_required
def active_list(request):
    query = request.GET.get("q", "")

    # Filter documents based on search query (e.g., searching by member name)
    documents = DocumentCustody.objects.all()
    if query:
        documents = documents.filter(member_name__icontains=query)  # Adjust field as needed

    # Pagination (10 records per page)
    paginator = Paginator(documents, 10)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    return render(request, "active_musingo.html", {"page_obj": page_obj, "query": query})


@login_required
def muno(request):
    return render(request, 'register_Musingo.html')

@login_required
def user_document_list(request):
    query = request.GET.get('q', '')
    documents = DocumentCustody.objects.all()
    if query:
        documents = documents.filter(account_number__icontains=query)
    documents = documents.order_by('-date_received')
    
    paginator = Paginator(documents, 10)  # 10 documents per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'user_document_list.html', {
        'page_obj': page_obj,
        'query': query,
    })



###################################################################################################################
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import Customer, DocumentCustody
from .forms import DocumentCustodyForm
@login_required
def register_document(request, cus_id):
    # Get the customer object or return 404 if not found
    customer = get_object_or_404(Customer, cus_id=cus_id)

    if request.method == 'POST':
        form = DocumentCustodyForm(request.POST)
        if form.is_valid():
            # Create the document instance but don't save it yet
            document = form.save(commit=False)
            # Assign the customer to the document
            document.customer = customer
            # Save the document to the database
            document.save()
            # Add a success message
            messages.success(request, f"Document '{document.document_type}' registered successfully for {customer.first_name} {customer.surname}.")
            # Redirect to a success page or back to the same page
            return redirect('register_document', cus_id=cus_id)  # Adjust redirect as needed
        else:
            # Add an error message if form is invalid
            messages.error(request, "Please correct the errors below.")
    else:
        # If GET request, initialize an empty form
        form = DocumentCustodyForm()

    # Render the template with customer and form context
    return render(request, 'register_document.html', {
        'customer': customer,
        'form': form,
    })
@login_required
def document_success(request):
    # Optional: A simple success page if you want a separate redirect target
    return render(request, 'register_document.html', {})

